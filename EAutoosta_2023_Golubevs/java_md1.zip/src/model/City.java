package model;

public enum City {
	Ventspils, Riga, Liepaja, Jelgava, Daugavpils, unknown
}
