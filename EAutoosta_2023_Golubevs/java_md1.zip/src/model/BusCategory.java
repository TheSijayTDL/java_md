package model;

public enum BusCategory {
	minibus, schoolbus, largebus, unknown
}
